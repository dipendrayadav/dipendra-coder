package com.niit.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MyController {

	@RequestMapping("/login")
	public String login() {

		return "login";
	}

	@RequestMapping("/registration")
	public String registration() {

		return "reg";
	}

	@RequestMapping("/allproducts")
	public String allproducts() {
		return "allproducts";
	}

	@RequestMapping("/prod")
	public ModelAndView showproduct(
			@RequestParam(value = "name", required = false, defaultValue = "World") String name) {

		ModelAndView mv = null;
		if (name.equals("guitar")) {

			mv = new ModelAndView("product");

			mv.addObject("pId", 1);
			mv.addObject("name", "Guitar");
			mv.addObject("price", "10000");
			mv.addObject("Description", "Electronic Guitar");

		}

		else if (name.equals("violin")) {
			mv = new ModelAndView("product");
			mv.addObject("pId", 2);
			mv.addObject("name", "violin");
			mv.addObject("price", "7000");
			mv.addObject("Description", "Violin");

		}

		else if (name.equals("drum")) {

			mv = new ModelAndView("product");
			mv.addObject("pId", 3);
			mv.addObject("name", "Drum");
			mv.addObject("price", "4500");
			mv.addObject("Description", "drum");

		}
		return mv;
	}
}
